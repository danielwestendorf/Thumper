::SEQUEL_NO_CORE_EXTENSIONS = true
require 'sequel'
